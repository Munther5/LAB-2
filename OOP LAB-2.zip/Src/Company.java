package employee_management;

public class Company {
    public static String getWelcomeMessage() {
        return "Welcome to XYZ Company!";
    }
}
