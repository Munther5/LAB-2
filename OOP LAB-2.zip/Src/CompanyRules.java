package employee_management;

public enum CompanyRules {
    DEFAULT_SALARY(5000);

    private final double value;

    CompanyRules(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }
}