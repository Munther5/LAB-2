package employee_management;

public class HR {
    private Employee[] employees;
    private int employeeCount;

    public HR() {
        employees = new Employee[15]; // Allows up to 15 employees
        employeeCount = 0;
    }

    public void addEmployee(Employee employee) {
        if (employeeCount < employees.length) {
            employees[employeeCount++] = employee;
            System.out.println("Employee added successfully!");
        } else {
            System.out.println("Cannot add more employees. Capacity full!");
        }
    }

    public boolean isEmployeeExists(int employeeId) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return true;
            }
        }
        return false;
    }

    public void updateBonus(int employeeId, double bonus) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                employees[i].setBonus(bonus);
                System.out.println("Bonus updated successfully!");
                return;
            }
        }
        System.out.println("Employee not found!");
    }

    public void displayAllEmployees() {
        if (employeeCount == 0) {
            System.out.println("No employees to display.");
            return;
        }
        System.out.println("Employee Details:");
        for (int i = 0; i < employeeCount; i++) {
            employees[i].displayDetails();
        }
    }
}
