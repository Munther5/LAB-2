package employee_management;

import java.util.Scanner;

public class EmployeeManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HR hr = new HR(); // Uses updated HR class with 15 employee capacity

        System.out.println(Company.getWelcomeMessage());

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add Employee");
            System.out.println("2. Update Bonus");
            System.out.println("3. Display All Employees");
            System.out.println("4. Display Welcome Message");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    if (hr.isEmployeeExists(15)) { // Prevents exceeding 15 employees
                        System.out.println("Maximum employees reached! Cannot add more.");
                        break;
                    }

                    System.out.print("Enter Employee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter Role: ");
                    String role = scanner.nextLine();
                    System.out.print("Enter Basic Salary (or enter 0 to use default salary): ");
                    double salary = scanner.nextDouble();

                    Employee employee = (salary > 0) ? 
                        new Employee(name, id, role, salary) :
                        new Employee(name, id, role);

                    hr.addEmployee(employee);
                    break;

                case 2:
                    System.out.print("Enter Employee ID: ");
                    int empId = scanner.nextInt();
                    System.out.print("Enter Bonus Amount: ");
                    double bonus = scanner.nextDouble();
                    hr.updateBonus(empId, bonus);
                    break;

                case 3:
                    hr.displayAllEmployees();
                    break;

                case 4:
                    System.out.println(Company.getWelcomeMessage());
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
