package employee_management;

public class Employee {
	private String name;
    private int employeeId;
    private String role;
    private double basicSalary;
    private double bonus;

    public Employee(String name, int employeeId, String role, double basicSalary) {
        this.name = name;
        this.employeeId = employeeId;
        this.role = role;
        this.basicSalary = basicSalary;
        this.bonus = 0; // Default bonus is 0
    }

    public Employee(String name, int employeeId, String role) {
        this(name, employeeId, role, CompanyRules.DEFAULT_SALARY.getValue());
    }

    public double calculateTotalSalary() {
        return basicSalary + bonus;
    }

    public void displayDetails() {
        System.out.println("ID: " + employeeId + ", Name: " + name + 
                ", Role: " + role + ", Total Salary: " + calculateTotalSalary());
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
}

